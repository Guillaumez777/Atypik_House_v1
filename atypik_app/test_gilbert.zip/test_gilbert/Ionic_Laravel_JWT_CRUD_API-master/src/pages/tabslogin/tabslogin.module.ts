import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TabsloginPage } from './tabslogin';

@NgModule({
  declarations: [
    TabsloginPage,
  ],
  imports: [
    IonicPageModule.forChild(TabsloginPage),
  ],
})
export class TabsloginPageModule {}
